from django.urls import path, include

app_name = 'knowledgebase'
urlpatterns = [
]
