from knowledgebase.models.base import PostCategory, Course, CourseSection, Lecture, SectionVideo,\
    SectionFile, Tutorial, Post
