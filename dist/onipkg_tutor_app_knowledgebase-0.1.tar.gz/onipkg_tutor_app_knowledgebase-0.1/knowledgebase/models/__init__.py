from tutor.apps.knowledgebase.models.base import PostCategory, Course, CourseSection, Lecture, SectionVideo,\
    SectionFile, Tutorial, Post
